const express = require("express"), webpush = require("web-push"), fs = require("fs"), path = require("path");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const DATA = process.env.DATA_DIR || __dirname;
const load = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DATA, f))); } catch (e) { return d; } };
const save = (f, v) => fs.writeFileSync(path.join(DATA, f), JSON.stringify(v));

let vapid = load("vapid.json", null);
if (!vapid) { vapid = webpush.generateVAPIDKeys(); save("vapid.json", vapid); }
webpush.setVapidDetails(process.env.VAPID_SUBJECT || "mailto:you@example.com", vapid.publicKey, vapid.privateKey);

let list = load("reminders.json", []);

app.get("/api/key", (req, res) => res.json({ key: vapid.publicKey }));

app.post("/api/remind", (req, res) => {
  const { id, text, at, sub } = req.body || {};
  if (!id || !text || !at || !sub || !sub.endpoint) return res.status(400).json({ error: "bad request" });
  list = list.filter(x => x.id !== id);
  list.push({ id, text, at, sub });
  save("reminders.json", list);
  res.json({ ok: true });
});

app.delete("/api/remind/:id", (req, res) => {
  list = list.filter(x => String(x.id) !== req.params.id);
  save("reminders.json", list);
  res.json({ ok: true });
});

setInterval(async () => {
  const now = Date.now();
  const due = list.filter(x => x.at <= now);
  if (!due.length) return;
  list = list.filter(x => x.at > now);
  save("reminders.json", list);
  for (const d of due) {
    try { await webpush.sendNotification(d.sub, JSON.stringify({ title: "Reminder", body: d.text })); }
    catch (e) { console.log("push failed", e.statusCode); }
  }
}, 2000);

app.listen(process.env.PORT || 3000, () => console.log("Reminder app running"));
