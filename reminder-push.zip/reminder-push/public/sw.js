self.addEventListener("push", (e) => {
  let d = { title: "Reminder", body: "" };
  try { d = e.data.json(); } catch (x) {}
  // Apple requires every push to show a notification.
  e.waitUntil(self.registration.showNotification(d.title, { body: d.body, icon: "icon.svg", requireInteraction: true }));
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: "window" }).then((cs) => cs.length ? cs[0].focus() : self.clients.openWindow("/")));
});
