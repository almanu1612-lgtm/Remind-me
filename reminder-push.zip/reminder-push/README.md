# Remind me (push notifications)

Run locally: `npm install && npm start` (http://localhost:3000; push needs HTTPS when deployed).

Deploy: push this folder to a Node host with HTTPS (Render, Railway, Fly.io). Start command: `npm start`.
Attach a persistent disk and set DATA_DIR to it, otherwise VAPID keys and reminders reset on redeploy
(a reset invalidates existing subscriptions: tap Enable notifications again).

iPhone/iPad (iOS/iPadOS 16.4+): open the site in Safari, Share > Add to Home Screen, open it from the icon,
tap Enable notifications. Notification sound is the system sound; a custom bell can't play while the app is closed.
